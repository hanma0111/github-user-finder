async function getUser() {
  const username = document.getElementById("username").value;
  const profileDiv = document.getElementById("profile");
  const reposDiv = document.getElementById("repos");

  profileDiv.innerHTML = "⏳ Loading...";
  reposDiv.innerHTML = "";

  try {
    // Fetch profile
    const profileResponse = await fetch(`https://api.github.com/users/${username}`);
    if (!profileResponse.ok) throw new Error("User not found");
    const user = await profileResponse.json();

    profileDiv.innerHTML = `
      <img src="${user.avatar_url}" alt="Avatar">
      <h2>${user.name || user.login}</h2>
      <p>${user.bio || "No bio available"}</p>
      <p>Followers: ${user.followers} | Following: ${user.following}</p>
      <p>Public Repos: ${user.public_repos}</p>
      <a href="${user.html_url}" target="_blank">View Profile</a>
    `;

    // Fetch repos
    const reposResponse = await fetch(user.repos_url + "?sort=updated&per_page=5");
    const repos = await reposResponse.json();

    reposDiv.innerHTML = "<h3>Latest Repositories:</h3>";
    repos.forEach(repo => {
      const repoEl = document.createElement("div");
      repoEl.classList.add("repo");
      repoEl.innerHTML = `
        <a href="${repo.html_url}" target="_blank">${repo.name}</a>
        <p>${repo.description || "No description"}</p>
      `;
      reposDiv.appendChild(repoEl);
    });

  } catch (error) {
    profileDiv.innerHTML = `<p style="color: red;">❌ ${error.message}</p>`;
  }
}

